# DCrap Landing Page

A simple, responsive landing page for the DCrap scrap collection app.

## Features

- 📱 **Fully Responsive** - Works on all devices (mobile, tablet, desktop)
- 🎨 **Modern UI** - Clean design matching the app's color scheme
- ⚡ **Fast & Lightweight** - Pure HTML, CSS, and JavaScript (no dependencies)
- 🎯 **Smooth Animations** - Fade-in effects and scroll animations
- 🔄 **Interactive Elements** - Hover effects, counter animations, and more

## Sections

1. **Navigation Bar** - Sticky header with mobile menu
2. **Hero Section** - Eye-catching banner with stats and phone mockup
3. **Features** - Key benefits of using DCrap
4. **How It Works** - 3-step process explanation
5. **Rates** - Current market rates for different scrap types
6. **CTA Section** - Call-to-action to download the app
7. **Footer** - Links and contact information

## Structure

```
landing_page/
├── index.html          # Main HTML file
├── styles.css          # All styles and responsive design
├── script.js           # JavaScript for interactivity
└── README.md           # This file
```

## Getting Started

Simply open `index.html` in your web browser:

1. Navigate to the landing_page folder
2. Double-click `index.html` or right-click and open with your browser
3. That's it! No build process or dependencies needed.

## Customization

### Colors
Edit the CSS variables in `styles.css`:
```css
:root {
    --primary-color: #3B82F6;
    --primary-dark: #2563EB;
    --secondary-color: #10B981;
    /* ... more colors */
}
```

### Content
- Modify text in `index.html`
- Update rates in the Rates section
- Change stats numbers in the Hero section
- Add or remove features in the Features grid

### Images
To add images:
1. Create an `images/` folder
2. Add your images
3. Update `<img>` tags in `index.html`

## Browser Support

- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Mobile browsers

## Features Included

### Interactive Elements
- Mobile hamburger menu
- Smooth scroll navigation
- Animated statistics counter
- Parallax effect on hero section
- Hover effects on cards
- Button ripple effects

### Responsive Breakpoints
- Mobile: < 480px
- Tablet: 481px - 768px
- Desktop: > 768px

## Performance

- **No external dependencies** - Everything is self-contained
- **Fast load time** - Minimal CSS and JavaScript
- **Optimized animations** - Hardware-accelerated transforms
- **SEO-friendly** - Semantic HTML structure

## Future Enhancements

Potential additions (would require backend):
- Contact form submission
- Newsletter signup
- Blog section
- User testimonials
- Live chat support
- App download links (iOS/Android)

## Deployment

This static site can be deployed to:

### Option 1: GitHub Pages
1. Push to GitHub repository
2. Enable GitHub Pages in settings
3. Select main branch and root folder

### Option 2: Netlify/Vercel
1. Drag and drop the folder to Netlify/Vercel
2. Site will be live instantly

### Option 3: Simple Web Server
```bash
# Using Python
python -m http.server 8000

# Using Node.js
npx serve

# Using PHP
php -S localhost:8000
```

Then visit `http://localhost:8000`

## Credits

Design inspired by the DCrap Flutter mobile application.

## License

This is a demo landing page created for the DCrap project.

---

**Need help?** Contact the development team or check the main project README.
